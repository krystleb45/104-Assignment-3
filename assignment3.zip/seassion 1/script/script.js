//object literal
/*const student1 ={
    fname:"Krystle",
    lname:"Berry",
    school:"San Diego Global Knowledge University",
    hobbies:["Reading","Play videogames", "Running"],
    address:{
        state:"VA",
        city:"Frederickburg",
        street:"University 1234",
        zip: "22406"
    }
}
const student2 ={
    fname:"Elijah",
    lname:"Berry",
    school:"San Diego Global Knowledge University",
    hobbies:["Reading","Play videogames", "Running"],
    address:{
        state:"World",
        city:"World",
        street:"world 1234",
        zip: "22406"
    }
}
//var state = student.address.state;
//console.log(state);//BC

//object destructuring
var{address:{state}}=student1;
console.log(state);*/

var saloon={
    name:"The Fashion Pet",
    address:{
        state:"Baja California",
        city:"Tijuana",
        street:"Unversity 1234",
        zip:"12345"
    },
    hours:{
        opening:"9:00 am",
        closing:"9:00 pm"
    },
    pets:[]
}
console.log(saloon);